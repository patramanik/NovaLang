# PowerShell Installer for NovaLang Windows SDK
$sdkDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$installDest = "$env:USERPROFILE\.nova"

Write-Host "=========================================" -ForegroundColor Cyan
Write-Host "     Installing NovaLang Windows SDK     " -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan

# 1. Create directory structures
Write-Host "[1/4] Copying SDK files to $installDest..." -ForegroundColor Yellow
if (Test-Path $installDest) {
    Remove-Item -Recurse -Force $installDest
}
New-Item -ItemType Directory -Force -Path "$installDest\bin" | Out-Null

# Copy files
Copy-Item -Path "$sdkDir\bin\nova.exe" -Destination "$installDest\bin\nova.exe"
Copy-Item -Recurse -Path "$sdkDir\stdlib" -Destination "$installDest\stdlib"
Copy-Item -Recurse -Path "$sdkDir\editors" -Destination "$installDest\editors"

# 2. Update Environment PATH
Write-Host "[2/4] Adding $installDest\bin to User PATH..." -ForegroundColor Yellow
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -notlike "*$installDest\bin*") {
    [Environment]::SetEnvironmentVariable("Path", "$userPath;$installDest\bin", "User")
    $env:Path = "$env:Path;$installDest\bin"
    Write-Host "Added to User PATH." -ForegroundColor Green
} else {
    Write-Host "PATH already registered." -ForegroundColor Green
}

# 3. Check / Install LLVM Clang dependency
Write-Host "[3/4] Checking for LLVM Clang compiler dependency..." -ForegroundColor Yellow
$clangPath = Get-Command clang -ErrorAction SilentlyContinue
if (-not $clangPath) {
    Write-Host "LLVM Clang compiler not found. Clang is required for native builds (nova build)." -ForegroundColor Yellow
    $choice = Read-Host "Would you like to install LLVM Clang automatically using winget? (Y/N)"
    if ($choice -eq "Y" -or $choice -eq "y") {
        Write-Host "Installing LLVM Clang via winget... This may take a moment." -ForegroundColor Yellow
        winget install --id LLVM.LLVM --silent --accept-source-agreements --accept-package-agreements
        if ($LASTEXITCODE -eq 0) {
            Write-Host "LLVM Clang installed successfully! Please restart all terminal windows to refresh your PATH." -ForegroundColor Green
        } else {
            Write-Host "winget installation returned code $LASTEXITCODE. You may need to install LLVM manually from: https://github.com/llvm/llvm-project/releases" -ForegroundColor Red
        }
    } else {
        Write-Host "Skipped LLVM installation. You must install Clang manually to run native compilations." -ForegroundColor Cyan
    }
} else {
    Write-Host "LLVM Clang detected at $($clangPath.Source)" -ForegroundColor Green
}

# 4. Complete
Write-Host "[4/4] Installation Complete!" -ForegroundColor Green
Write-Host "Please restart your terminal window." -ForegroundColor Yellow
Write-Host "Test the installation using: nova repl" -ForegroundColor Cyan
Write-Host "=========================================" -ForegroundColor Cyan
