# NovaLang SDK for Windows

Welcome to the NovaLang Software Development Kit (SDK) for Windows!

## Contents
* `bin/nova.exe` - Standalone compiled compiler, VM runtime, and REPL manager.
* `stdlib/` - Reference code files for standard library modules.
* `editors/` - Syntax definitions and configuration packages for IDEs (e.g. VS Code).
* `install.ps1` - PowerShell installation automation script.

## Setup Instructions

1. Open PowerShell as an administrator or user.
2. Navigate to the extracted SDK folder.
3. Run the installer script:
   ```powershell
   .\install.ps1
   ```
4. Restart your terminal window to reload the PATH variable.
5. Verify the installation:
   ```cmd
   nova repl
   ```

Happy coding with NovaLang!
